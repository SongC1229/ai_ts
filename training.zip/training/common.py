"""训练公共工具：配置加载、设备解析

train.py / evaluate.py 共用,避免 load_yaml 重复实现导致行为不一致。
"""

import re

import torch


def load_yaml(path: str) -> dict:
    """加载简易 YAML 配置文件（纯 Python 实现,无 PyYAML 依赖)

    仅支持扁平 key: value 形式,值的类型推断:
    - true/false → bool
    - auto → 字符串 'auto'
    - null 或空 → None
    - 整数 / 浮点数 → 数字
    - 其它 → 去引号的字符串
    """
    cfg = {}
    with open(path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.split('#')[0].strip()
            if not line:
                continue
            m = re.match(r'^(\w[\w_]*)\s*:\s*(.*)', line)
            if not m:
                continue
            key = m.group(1)
            val = m.group(2).strip()
            if val == '' or val == 'null':
                cfg[key] = None
            elif val == 'true':
                cfg[key] = True
            elif val == 'false':
                cfg[key] = False
            elif val == 'auto':
                cfg[key] = 'auto'
            else:
                try:
                    cfg[key] = int(val)
                except ValueError:
                    try:
                        cfg[key] = float(val)
                    except ValueError:
                        cfg[key] = val.strip("'\"")
    return cfg


def resolve_device(device_str: str) -> torch.device:
    """解析设备字符串,'auto' 自动选择 cuda/cpu"""
    if device_str == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    return torch.device(device_str)
