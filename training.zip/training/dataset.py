#!/usr/bin/env python3
"""WavLM 性别检测数据集 — 与推理侧预处理一致

用法:
    from dataset import WavLMGenderDataset, collate_fn
    dataset = WavLMGenderDataset("training/data/train.jsonl", max_sec=15)
    loader = DataLoader(dataset, batch_size=8, collate_fn=collate_fn)
"""

import json
import os

import torch
import torch.nn.functional as F
import soundfile as sf
from torch.utils.data import Dataset


class WavLMGenderDataset(Dataset):
    """WavLM 性别检测训练数据集

    预处理与推理侧 wavlm_gender_api._load_audio 保持一致:
    - 16kHz 单声道
    - 截断/补齐到 max_samples 个采样点
    - 返回 raw waveform（由模型内部的 Wav2Vec2FeatureExtractor 二次处理)
    """

    def __init__(self, jsonl_path: str, max_sec: float = 15.0, sample_rate: int = 16000):
        super().__init__()
        self.max_samples = int(max_sec * sample_rate)
        self.sample_rate = sample_rate
        self.items = []

        if not os.path.exists(jsonl_path):
            raise FileNotFoundError(f"JSONL 文件不存在: {jsonl_path}")

        with open(jsonl_path, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if line:
                    self.items.append(json.loads(line))

        if not self.items:
            raise ValueError(f"JSONL 文件为空: {jsonl_path}")

    def __len__(self):
        return len(self.items)

    def __getitem__(self, idx):
        item = self.items[idx]
        path = item["path"]
        label = item["label"]
        start_sec = item.get("start_sec", 0)
        end_sec = item.get("end_sec", 0)

        # 读取音频（与推理侧 _load_audio 一致)
        audio, sr = sf.read(path)

        # 多声道 → 单声道
        if audio.ndim > 1:
            audio = audio.mean(axis=1)

        # 重采样到 16kHz
        if sr != self.sample_rate:
            import librosa
            audio = librosa.resample(audio, orig_sr=sr, target_sr=self.sample_rate)

        # 截取指定区间
        start_sample = int(start_sec * self.sample_rate)
        end_sample = int(end_sec * self.sample_rate) if end_sec > 0 else len(audio)
        if end_sample > len(audio):
            end_sample = len(audio)
        audio = audio[start_sample:end_sample]

        # 截断到 max_samples（与推理侧一致)
        if len(audio) > self.max_samples:
            audio = audio[:self.max_samples]

        # 转为 tensor
        waveform = torch.from_numpy(audio).float()

        return waveform, label

    @staticmethod
    def collate_fn(batch):
        """批量 padding 对齐到 batch 内最长（与 detect_genders_batch 的 padding 一致)

        Args:
            batch: [(waveform_tensor, label), ...]

        Returns:
            padded_waveforms: (batch, max_len) float32 tensor
            labels: (batch,) long tensor
            lengths: (batch,) int tensor — 各样本原始长度
        """
        waveforms, labels = zip(*batch)
        lengths = torch.tensor([w.shape[0] for w in waveforms], dtype=torch.long)
        max_len = max(lengths).item()

        padded = []
        for w in waveforms:
            pad_len = max_len - w.shape[0]
            if pad_len > 0:
                w = F.pad(w, (0, pad_len))
            padded.append(w)

        return torch.stack(padded), torch.tensor(labels, dtype=torch.long), lengths
