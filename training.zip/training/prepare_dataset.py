#!/usr/bin/env python3
"""数据准备：扫描原始音频目录 → 生成 train/val JSONL 清单

用法:
    python training/prepare_dataset.py --data_dir training/data

输入约定:
    training/data/
    ├── female/   (xxx.wav xxx.flac ...)
    └── male/     (xxx.wav xxx.flac ...)

    也支持单 CSV 文件 data_dir/metadata.csv (path,gender) 作为备选。

输出:
    training/data/train.jsonl
    training/data/val.jsonl
    每行: {"path": "...", "label": 0|1, "gender": "female|male"}
    label: 0=female, 1=male（与 WavLM _parse_sex_logits 一致)
"""

import argparse
import json
import os
import random
import sys

import soundfile as sf


def scan_directory(data_dir: str, max_sec: float = 15.0) -> list:
    """递归扫描 female/ 和 male/ 子目录,返回 [{path, label, gender, duration_sec}]"""
    items = []
    label_map = {"female": 0, "male": 1}

    for gender_name, label in label_map.items():
        gender_dir = os.path.join(data_dir, gender_name)
        if not os.path.isdir(gender_dir):
            print(f"  ⚠️ 目录不存在: {gender_dir}")
            continue

        for root, _, files in os.walk(gender_dir):
            for fname in sorted(files):
                if not fname.lower().endswith(('.wav', '.flac', '.mp3')):
                    continue
                path = os.path.join(root, fname)
                try:
                    info = sf.info(path)
                    dur = info.frames / info.samplerate
                except Exception as e:
                    print(f"  ⚠️ 无法读取 {path}: {e}")
                    continue

                if dur < 1.0:
                    print(f"  ⚠️ 跳过过短音频 ({dur:.1f}s): {path}")
                    continue

                if dur > max_sec:
                    # 长音频按 max_sec 切片,生成多个完整片段 + 一个不足的尾部片段
                    n_chunks = int(dur // max_sec)
                    for ci in range(n_chunks):
                        items.append({
                            "path": path,
                            "label": label,
                            "gender": gender_name,
                            "start_sec": ci * max_sec,
                            "end_sec": min((ci + 1) * max_sec, dur),
                            "duration_sec": min(max_sec, dur - ci * max_sec),
                            "chunk": ci,
                        })
                    # 尾部不足一个 max_sec 的片段（仅当 >= 1s 时保留)
                    tail_start = n_chunks * max_sec
                    tail_dur = dur - tail_start
                    if tail_dur >= 1.0:
                        items.append({
                            "path": path,
                            "label": label,
                            "gender": gender_name,
                            "start_sec": tail_start,
                            "end_sec": dur,
                            "duration_sec": tail_dur,
                            "chunk": n_chunks,
                        })
                else:
                    items.append({
                        "path": path,
                        "label": label,
                        "gender": gender_name,
                        "start_sec": 0,
                        "end_sec": dur,
                        "duration_sec": dur,
                    })

    return items


def train_val_split(items: list, val_ratio: float, seed: int):
    """按性别分层随机拆分为 train/val"""
    random.seed(seed)
    female_items = [it for it in items if it["gender"] == "female"]
    male_items = [it for it in items if it["gender"] == "male"]

    def _split(group):
        random.shuffle(group)
        n_val = max(1, int(len(group) * val_ratio))
        return group[n_val:], group[:n_val]

    train_f, val_f = _split(female_items)
    train_m, val_m = _split(male_items)

    train = train_f + train_m
    val = val_f + val_m
    random.shuffle(train)
    random.shuffle(val)
    return train, val


def to_jsonl(items: list, output_path: str):
    """写入 JSONL,每行保留 path/label/gender 三字段"""
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, 'w', encoding='utf-8') as f:
        for it in items:
            record = {
                "path": it["path"],
                "label": it["label"],
                "gender": it["gender"],
                "start_sec": it.get("start_sec", 0),
                "end_sec": it.get("end_sec", it["duration_sec"]),
            }
            f.write(json.dumps(record, ensure_ascii=False) + '\n')


def main():
    parser = argparse.ArgumentParser(description="准备 WavLM 性别检测训练数据")
    parser.add_argument("--data_dir", default="training/data", help="数据目录")
    parser.add_argument("--val_ratio", type=float, default=0.05, help="验证集比例")
    parser.add_argument("--seed", type=int, default=42, help="随机种子")
    parser.add_argument("--max_sec", type=float, default=15.0, help="音频最大长度(秒)")
    args = parser.parse_args()

    print(f"  [准备数据] 扫描 {args.data_dir} ...")
    items = scan_directory(args.data_dir, max_sec=args.max_sec)

    if not items:
        print("  ❌ 未找到任何音频文件,请检查目录结构:")
        print(f"      {args.data_dir}/female/ 和 {args.data_dir}/male/")
        sys.exit(1)

    total_dur = sum(it["duration_sec"] for it in items)
    n_female = sum(1 for it in items if it["gender"] == "female")
    n_male = sum(1 for it in items if it["gender"] == "male")
    print(f"  扫描完成: {len(items)} 条, {total_dur/3600:.1f}h")
    print(f"    女: {n_female} 条, 男: {n_male} 条")

    train, val = train_val_split(items, args.val_ratio, args.seed)
    train_dur = sum(it["duration_sec"] for it in train)
    val_dur = sum(it["duration_sec"] for it in val)

    to_jsonl(train, os.path.join(args.data_dir, "train.jsonl"))
    to_jsonl(val, os.path.join(args.data_dir, "val.jsonl"))
    print(f"  训练集: {len(train)} 条 ({train_dur/3600:.1f}h)")
    print(f"  验证集: {len(val)} 条 ({val_dur/3600:.1f}h)")
    print(f"  输出: {args.data_dir}/train.jsonl, {args.data_dir}/val.jsonl")
    print("  ✅ 数据准备完成")


if __name__ == '__main__':
    main()
