#!/usr/bin/env python3
"""WavLM 性别检测模型独立评估

用法:
    python training/evaluate.py --model_dir models/wavlm-large-age-sex-ja
    python training/evaluate.py --model_dir models/wavlm-large-age-sex-ja --val_jsonl training/data/val.jsonl
"""

import argparse
import os
import sys

import numpy as np
import torch

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, PROJECT_ROOT)

from training.common import load_yaml, resolve_device  # noqa: E402


def main():
    parser = argparse.ArgumentParser(description="WavLM 性别检测评估")
    parser.add_argument("--model_dir", default="models/wavlm-large-age-sex-ja",
                        help="模型目录（含 config.json + model.safetensors)")
    parser.add_argument("--val_jsonl", default=None,
                        help="验证集 JSONL（默认从 config 中读取)")
    parser.add_argument("--batch_size", type=int, default=16, help="批大小")
    parser.add_argument("--device", default="auto", help="推理设备")
    args = parser.parse_args()

    # 设备
    device = resolve_device(args.device)
    print(f"  设备: {device}")

    # 模型
    model_dir = os.path.join(PROJECT_ROOT, args.model_dir)
    if not os.path.exists(model_dir):
        print(f"  ❌ 模型目录不存在: {model_dir}")
        sys.exit(1)

    print(f"  加载模型: {model_dir}")
    from core.wavlm_model import WavLMWrapper

    model = WavLMWrapper.from_pretrained(model_dir)
    model = model.to(device)
    model.eval()

    # 数据
    val_jsonl = args.val_jsonl
    if val_jsonl is None:
        # 从默认 config 读取
        config_path = os.path.join(PROJECT_ROOT, "training/configs/train_ja.yaml")
        if os.path.exists(config_path):
            cfg = load_yaml(config_path)
            val_jsonl = cfg.get('val_jsonl', 'training/data/val.jsonl')
        else:
            val_jsonl = "training/data/val.jsonl"

    val_path = os.path.join(PROJECT_ROOT, val_jsonl)
    if not os.path.exists(val_path):
        print(f"  ❌ 验证集不存在: {val_path}")
        sys.exit(1)

    print(f"  加载数据: {val_path}")
    from training.dataset import WavLMGenderDataset
    from torch.utils.data import DataLoader

    dataset = WavLMGenderDataset(val_path, max_sec=15)
    loader = DataLoader(
        dataset,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=2,
        collate_fn=WavLMGenderDataset.collate_fn,
    )
    print(f"  验证集: {len(dataset)} 条")

    # 推理
    print("\n  ===== 开始评估 =====")
    all_preds = []
    all_labels = []
    all_logits = []

    with torch.no_grad():
        for waveforms, labels, lengths in loader:
            waveforms = waveforms.to(device)
            _, sex_logits = model(waveforms)
            preds = sex_logits.argmax(dim=1)

            all_preds.extend(preds.cpu().numpy())
            all_labels.extend(labels.numpy())
            all_logits.extend(sex_logits.cpu().numpy())

    all_preds = np.array(all_preds)
    all_labels = np.array(all_labels)
    all_logits = np.array(all_logits)

    # 统计
    total = len(all_labels)
    correct = (all_preds == all_labels).sum()
    acc = correct / total

    female_mask = all_labels == 0
    male_mask = all_labels == 1
    f_correct = ((all_preds == all_labels) & female_mask).sum()
    m_correct = ((all_preds == all_labels) & male_mask).sum()
    f_total = female_mask.sum()
    m_total = male_mask.sum()

    print("\n  📊 评估结果:")
    print(f"  整体准确率: {acc:.4f} ({correct}/{total})")
    print(f"  女声召回率: {f_correct/f_total:.4f} ({f_correct}/{f_total})" if f_total > 0 else "  女声: 无样本")
    print(f"  男声召回率: {m_correct/m_total:.4f} ({m_correct}/{m_total})" if m_total > 0 else "  男声: 无样本")

    # 混淆矩阵
    print("\n  混淆矩阵:")
    cm = np.zeros((2, 2), dtype=int)
    for t, p in zip(all_labels, all_preds):
        cm[t, p] += 1
    print("          预测女   预测男")
    print(f"  实际女  {cm[0,0]:6d}  {cm[0,1]:6d}")
    print(f"  实际男  {cm[1,0]:6d}  {cm[1,1]:6d}")

    # 置信度分布
    probs = torch.softmax(torch.from_numpy(all_logits), dim=1).numpy()
    correct_probs = probs[all_preds == all_labels].max(axis=1)
    wrong_probs = probs[all_preds != all_labels].max(axis=1)
    if len(correct_probs) > 0:
        print(f"\n  正确预测平均置信度: {correct_probs.mean():.4f}")
    if len(wrong_probs) > 0:
        print(f"  错误预测平均置信度: {wrong_probs.mean():.4f}")

    print("\n  ✅ 评估完成")


if __name__ == '__main__':
    main()
