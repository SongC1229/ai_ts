# WavLM-Large-Age-Sex 日语性别检测 LoRA 微调

## 环境要求

项目已有依赖（无需额外安装）：
- Python 3.10+
- torch >= 2.4
- transformers >= 4.46
- loralib >= 0.1.2
- soundfile, librosa, numpy, safetensors

## 三步流程

### 1. 准备数据

把原始日语男女声音频放到 `training/data/` 下，按性别分子目录：

```
training/data/
├── female/   (xxx.wav, xxx.flac, xxx.mp3 ...)
└── male/     (xxx.wav, xxx.flac, xxx.mp3 ...)
```

支持 .wav / .flac / .mp3 格式。音频会被自动校验（跳过 <1s 的过短文件），长音频按 15s 切片。

然后运行数据准备脚本：

```bash
python training/prepare_dataset.py --data_dir training/data
```

输出：
- `training/data/train.jsonl` — 训练集（默认 95%）
- `training/data/val.jsonl` — 验证集（默认 5%）

### 2. 训练

```bash
python training/train.py
```

自动从 `training/configs/train_ja.yaml` 读取配置。
首次运行从预训练权重开始，如果有 `training/checkpoints/latest.pt` 则自动恢复继续训练。

可选参数：
- `--eval-only` — 仅评估已有模型，不训练

训练产物保存到 `models/wavlm-large-age-sex-ja/`：
```
models/wavlm-large-age-sex-ja/
├── config.json              # 与原模型 11 字段一致
├── model.safetensors        # 全量 state_dict（LoRA 融合后）
└── README.md                # 训练记录
```

Checkpoint 保存在 `training/checkpoints/`：
- `checkpoint_epoch{01..N}.pt` — 每 epoch 一份
- `latest.pt` — 始终指向最新（`--resume latest` 用）

### 3. 评估

```bash
python training/evaluate.py --model_dir models/wavlm-large-age-sex-ja
```

输出：整体准确率、男女各自召回率、混淆矩阵、置信度分布。

## 产物加载

```python
from core.wavlm_model import WavLMWrapper
model = WavLMWrapper.from_pretrained("models/wavlm-large-age-sex-ja")
```

与现有 `wavlm_gender_api.py` 兼容，替换模型目录即可使用。

## 超参说明

| 参数 | 默认值 | 说明 |
|------|--------|------|
| lora_rank | 16 | LoRA 秩（与原模型一致） |
| batch_size | 8 | 每批样本数（根据显存调整） |
| epochs | 5 | 训练轮数 |
| lr | 1e-4 | 学习率 |
| weight_decay | 0.01 | AdamW 权重衰减 |
| warmup_ratio | 0.1 | 学习率预热比例 |
| fp16 | true | 混合精度训练（仅 GPU） |
| max_audio_sec | 15 | 音频最大长度（与推理一致） |

## 技术细节

- 标签顺序：[Female=0, Male=1]（与 `_parse_sex_logits` 一致）
- 预处理：16kHz mono，截断/补齐到 15s，raw waveform 喂入
- LoRA 仅加在后半层 feed-forward 网络（与现有架构一致）
- 训练冻结骨干网络，仅 LoRA 参数 + 下游头可训练
- 保存全量 state_dict，推理侧零改动即可加载
