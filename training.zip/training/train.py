#!/usr/bin/env python3
"""WavLM-Large-Age-Sex 日语性别检测 LoRA 微调

从项目根目录运行:
    python training/train.py --config training/configs/train_ja.yaml

产物: models/wavlm-large-age-sex-ja/
    ├── config.json    (与原模型 11 字段一致)
    ├── model.safetensors (全量 state_dict,含 LoRA + 下游头)
    └── README.md
"""

import argparse
import os
import shutil
import sys
import time

import loralib as lora
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from torch.utils.tensorboard import SummaryWriter

# 项目根目录
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, PROJECT_ROOT)

from training.common import load_yaml, resolve_device  # noqa: E402


def get_linear_warmup_cosine_scheduler(optimizer, warmup_steps, total_steps):
    """warmup + cosine decay scheduler"""
    def lr_lambda(step):
        if step < warmup_steps:
            return float(step) / float(max(1, warmup_steps))
        progress = float(step - warmup_steps) / float(max(1, total_steps - warmup_steps))
        return 0.5 * (1.0 + torch.cos(torch.tensor(progress * 3.1415926535)))
    return torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda)


def evaluate(model, val_loader, device, fp16=False):
    """在验证集上评估模型,返回 (accuracy, correct, total, female_acc, male_acc)"""
    model.eval()
    correct = 0
    total = 0
    correct_female = 0
    total_female = 0
    correct_male = 0
    total_male = 0

    with torch.no_grad():
        for waveforms, labels, lengths in val_loader:
            waveforms = waveforms.to(device)
            labels = labels.to(device)

            with torch.amp.autocast('cuda', enabled=fp16 and device.type == 'cuda'):
                _, sex_logits = model(waveforms)
                preds = sex_logits.argmax(dim=1)

            correct += (preds == labels).sum().item()
            total += labels.size(0)

            # 按性别分别统计
            is_female = (labels == 0)
            is_male = (labels == 1)
            correct_female += ((preds == labels) & is_female).sum().item()
            total_female += is_female.sum().item()
            correct_male += ((preds == labels) & is_male).sum().item()
            total_male += is_male.sum().item()

    acc = correct / total if total > 0 else 0.0
    f_acc = correct_female / total_female if total_female > 0 else 0.0
    m_acc = correct_male / total_male if total_male > 0 else 0.0

    model.train()
    return acc, correct, total, f_acc, m_acc


def main():
    parser = argparse.ArgumentParser(description="WavLM 性别检测 LoRA 微调")
    parser.add_argument("--config", default="training/configs/train_ja.yaml",
                        help="配置文件路径")
    parser.add_argument("--eval-only", action="store_true", help="仅评估,不训练")
    args = parser.parse_args()

    # 加载配置
    cfg_path = os.path.join(PROJECT_ROOT, args.config) \
        if not os.path.isabs(args.config) else args.config
    cfg = load_yaml(cfg_path)
    print(f"  [训练] 加载配置: {args.config}")
    for k, v in cfg.items():
        print(f"    {k}: {v}")

    # 设备
    device = resolve_device(cfg.get("device", "auto"))
    fp16 = cfg.get("fp16", True) and device.type == "cuda"
    print(f"  设备: {device}, FP16: {fp16}")
    use_amp = fp16

    # 数据
    print(f"  加载训练数据: {cfg['train_jsonl']}")
    sys.path.insert(0, PROJECT_ROOT)
    from training.dataset import WavLMGenderDataset

    train_dataset = WavLMGenderDataset(
        os.path.join(PROJECT_ROOT, cfg['train_jsonl']),
        max_sec=cfg.get('max_audio_sec', 15),
    )
    val_dataset = WavLMGenderDataset(
        os.path.join(PROJECT_ROOT, cfg['val_jsonl']),
        max_sec=cfg.get('max_audio_sec', 15),
    )
    train_loader = DataLoader(
        train_dataset,
        batch_size=cfg.get('batch_size', 8),
        shuffle=True,
        num_workers=cfg.get('num_workers', 4),
        collate_fn=WavLMGenderDataset.collate_fn,
        pin_memory=device.type == 'cuda',
    )
    val_loader = DataLoader(
        val_dataset,
        batch_size=cfg.get('batch_size', 8) * 2,
        shuffle=False,
        num_workers=cfg.get('num_workers', 4),
        collate_fn=WavLMGenderDataset.collate_fn,
        pin_memory=device.type == 'cuda',
    )
    print(f"  训练: {len(train_dataset)} 条, 验证: {len(val_dataset)} 条")

    # 模型
    print(f"  加载预训练模型: {cfg['pretrained_dir']}")
    pretrained_path = os.path.join(PROJECT_ROOT, cfg['pretrained_dir'])
    from core.wavlm_model import WavLMWrapper

    model = WavLMWrapper.from_pretrained(pretrained_path)
    model = model.to(device)
    model.train()

    # 梯度检查点（省显存,略慢)
    if cfg.get('gradient_checkpointing', False):
        if hasattr(model.backbone_model, 'gradient_checkpointing_enable'):
            model.backbone_model.gradient_checkpointing_enable()
            print("  梯度检查点已启用")

    # LoRA 准备
    lora.mark_only_lora_as_trainable(model)
    trainable_params = [p for p in model.parameters() if p.requires_grad]
    n_params = sum(p.numel() for p in trainable_params)
    print(f"  可训练参数: {n_params:,}")

    # 自动从最新 checkpoint 恢复（如果存在)
    # 先读取标量信息 + 加载模型权重；优化器/调度器状态待它们构建后再加载
    start_epoch = 0
    best_val_acc = 0.0
    global_step = 0
    ckpt = None
    latest_ckpt = os.path.join(PROJECT_ROOT, "training", "checkpoints", "latest.pt")
    if os.path.exists(latest_ckpt):
        print(f"  检测到 checkpoint: {latest_ckpt}")
        ckpt = torch.load(latest_ckpt, map_location=device)
        model.load_state_dict(ckpt['model_state_dict'])
        start_epoch = ckpt['epoch'] + 1
        best_val_acc = ckpt.get('best_val_acc', 0.0)
        global_step = ckpt.get('global_step', 0)
        print(f"    从 epoch {start_epoch}, global_step {global_step} 恢复")

    # 优化器
    optimizer = torch.optim.AdamW(
        trainable_params,
        lr=cfg.get('lr', 1e-4),
        weight_decay=cfg.get('weight_decay', 0.01),
    )

    # 学习率调度（warmup 只在最开始做一次,恢复时不重新 warmup)
    epochs = cfg.get('epochs', 5)
    steps_per_epoch = len(train_loader)
    if start_epoch > 0:
        warmup_steps = 0
    else:
        warmup_steps = int(steps_per_epoch * epochs * cfg.get('warmup_ratio', 0.1))
    scheduler = get_linear_warmup_cosine_scheduler(optimizer, warmup_steps,
                                                    steps_per_epoch * epochs)

    # 恢复优化器/调度器状态（需要在它们构建之后)
    if ckpt is not None:
        optimizer.load_state_dict(ckpt['optimizer_state_dict'])
        if 'scheduler_state_dict' in ckpt:
            scheduler.load_state_dict(ckpt['scheduler_state_dict'])

    # 损失函数
    criterion = nn.CrossEntropyLoss()

    # GradScaler（配合 fp16 autocast,防止梯度下溢出 NaN)
    scaler = torch.amp.GradScaler('cuda', enabled=use_amp)

    # 仅评估
    if args.eval_only:
        print("\n  ===== 评估模式 =====")
        acc, correct, total, f_acc, m_acc = evaluate(model, val_loader, device, use_amp)
        print(f"  验证集准确率: {acc:.4f} ({correct}/{total})")
        print(f"    女: {f_acc:.4f}, 男: {m_acc:.4f}")
        return

    # TensorBoard
    log_dir = os.path.join(PROJECT_ROOT, "training", "logs")
    writer = SummaryWriter(log_dir)

    # 输出目录
    output_dir = os.path.join(PROJECT_ROOT, cfg['output_dir'])
    os.makedirs(output_dir, exist_ok=True)

    # 训练循环
    print(f"\n  ===== 开始训练 ({epochs} epochs) =====")
    log_steps = cfg.get('log_steps', 10)
    no_improve_epochs = 0
    grad_accum = max(cfg.get('gradient_accumulation_steps', 1), 1)

    for epoch in range(start_epoch, epochs):
        epoch_start = time.time()
        model.train()
        epoch_loss = 0.0

        for batch_idx, (waveforms, labels, lengths) in enumerate(train_loader):

            waveforms = waveforms.to(device)
            labels = labels.to(device)
            lengths = lengths.to(device)

            with torch.amp.autocast('cuda', enabled=use_amp):
                _, sex_logits = model(waveforms)
                loss = criterion(sex_logits, labels)
            loss = loss / grad_accum

            scaler.scale(loss).backward()

            if (batch_idx + 1) % grad_accum == 0:
                scaler.unscale_(optimizer)
                torch.nn.utils.clip_grad_norm_(trainable_params, 5.0)
                scaler.step(optimizer)
                scaler.update()
                scheduler.step()
                optimizer.zero_grad()

            epoch_loss += loss.item()
            global_step += 1

            if (batch_idx + 1) % log_steps == 0:
                lr_now = optimizer.param_groups[0]['lr']
                print(f"    E{epoch+1}/{epochs} B{batch_idx+1}/{len(train_loader)} "
                      f"loss={loss.item():.4f} lr={lr_now:.2e}")
                writer.add_scalar('train/loss', loss.item(), global_step)
                writer.add_scalar('train/lr', lr_now, global_step)

        # Epoch 结束
        avg_loss = epoch_loss / len(train_loader)
        epoch_time = time.time() - epoch_start
        print(f"\n  Epoch {epoch+1}/{epochs} 完成, "
              f"avg_loss={avg_loss:.4f}, time={epoch_time:.1f}s")

        # 验证
        acc, correct, total, f_acc, m_acc = evaluate(model, val_loader, device, use_amp)
        print(f"  验证: acc={acc:.4f} ({correct}/{total}), "
              f"女={f_acc:.4f}, 男={m_acc:.4f}")
        writer.add_scalar('val/accuracy', acc, epoch)
        writer.add_scalar('val/female_accuracy', f_acc, epoch)
        writer.add_scalar('val/male_accuracy', m_acc, epoch)

        # 保存最佳模型
        if acc > best_val_acc:
            best_val_acc = acc
            no_improve_epochs = 0
            print(f"  🏆 最佳模型 (acc={acc:.4f})")
            _save_model(model, output_dir, cfg, epoch, acc)
            print(f"    保存到: {output_dir}")
        else:
            no_improve_epochs += 1
            print(f"  📉 连续 {no_improve_epochs} epoch 未提升")

        # 早停（连续 2 epoch val 无提升 → 停止,节省时间)
        patience = cfg.get('early_stop_patience', 2)
        if no_improve_epochs >= patience and epoch >= 2:
            print(f"\n  🛑 连续 {patience} epoch 验证准确率未提升,提前停止")
            break

        # 保存 checkpoint（含优化器+调度器状态,支持恢复后继续)
        ckpt_dir = os.path.join(PROJECT_ROOT, "training", "checkpoints")
        os.makedirs(ckpt_dir, exist_ok=True)
        ckpt = {
            'epoch': epoch,
            'global_step': global_step,
            'model_state_dict': model.state_dict(),
            'optimizer_state_dict': optimizer.state_dict(),
            'scheduler_state_dict': scheduler.state_dict(),
            'best_val_acc': best_val_acc,
        }
        # 按 epoch 保存
        torch.save(ckpt, os.path.join(ckpt_dir, f"checkpoint_epoch{epoch+1:02d}.pt"))
        # 覆盖 latest.pt（始终指向最新,方便 --resume 无需指定编号)
        torch.save(ckpt, os.path.join(ckpt_dir, "latest.pt"))
        print(f"  checkpoint 已保存: checkpoint_epoch{epoch+1:02d}.pt, latest.pt")

    # 最终评估
    print("\n  ===== 训练完成 =====")
    print(f"  最佳验证准确率: {best_val_acc:.4f}")
    print(f"  模型已保存到: {output_dir}")
    writer.close()


def _save_model(model, output_dir: str, cfg: dict, epoch: int, val_acc: float):
    """保存模型产物：config.json + model.safetensors + README.md"""
    # 1. 复制 config.json（11 字段原样保留)
    src_config = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                              cfg['pretrained_dir'], "config.json")
    if os.path.exists(src_config):
        shutil.copy2(src_config, os.path.join(output_dir, "config.json"))

    # 2. 保存全量 state_dict（safetensors 格式)
    state_dict = model.state_dict()
    from safetensors.torch import save_file
    # 转为 CPU tensor dict
    cpu_state = {k: v.contiguous().cpu() for k, v in state_dict.items()}
    save_file(cpu_state, os.path.join(output_dir, "model.safetensors"))

    # 3. 写入 README.md
    readme = f"""# WavLM-Large-Age-Sex 日语性别检测模型

## 训练信息
- 数据集: {cfg.get('train_jsonl', 'unknown')}
- 训练轮数: {epoch + 1}
- 验证准确率: {val_acc:.4f}
- LoRA rank: {cfg.get('lora_rank', 16)}
- 训练日期: {time.strftime('%Y-%m-%d')}

## 加载方式
```python
from core.wavlm_model import WavLMWrapper
model = WavLMWrapper.from_pretrained("models/wavlm-large-age-sex-ja")
```
"""
    with open(os.path.join(output_dir, "README.md"), 'w', encoding='utf-8') as f:
        f.write(readme)


if __name__ == '__main__':
    main()
