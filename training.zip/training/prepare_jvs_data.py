#!/usr/bin/env python3
"""JVS 语料 → WavLM 性别检测训练数据 转换脚本

用法:
    python training/prepare_jvs_data.py

流程:
    1. 读取 models/jvs_ver1/gender_f0range.txt 获取说话人→性别映射
    2. 扫描所有 jvsXXX/ 目录下的 wav24kHz16bit/ 子目录（含 parallel100,
       nonpara30, whisper10, falset10)
    3. 重采样到 16kHz 单声道,按性别分入 training/data/female/ 和
       training/data/male/
    4. 完成后输出统计数据

输出目录结构:
    training/data/
    ├── female/    (jvs001_parallel100_VOICEACTRESS100_001.wav, ...)
    └── male/      (...
"""
import os
import sys
import time

# 项目根目录
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, PROJECT_ROOT)

import soundfile as sf
import librosa


# ── 配置 ──────────────────────────────────────────────────────────────
JVS_DIR = os.path.join(PROJECT_ROOT, "models", "jvs_ver1")
GENDER_FILE = os.path.join(JVS_DIR, "gender_f0range.txt")
OUTPUT_DIR = os.path.join(PROJECT_ROOT, "training", "data")
TARGET_SR = 16000

# 要处理的子集（按顺序)
SUBSETS = ["parallel100", "nonpara30", "whisper10", "falset10"]


# ── 工具函数 ──────────────────────────────────────────────────────────

def parse_gender_map(path: str) -> dict:
    """解析 gender_f0range.txt → {speaker_id: "male"/"female"}"""
    mapping = {}
    with open(path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("speaker"):
                continue  # 跳过标题行
            parts = line.split()
            if len(parts) < 2:
                continue
            speaker = parts[0]  # e.g. jvs001
            gender = "male" if parts[1].upper() == "M" else "female"
            mapping[speaker] = gender
    return mapping


def collect_audio_files(jvs_dir: str, subsets: list) -> list:
    """扫描所有 speaker 的 wav24kHz16bit 子目录,返回文件信息列表

    Returns:
        [(speaker_id, subset, rel_path, abs_path), ...]
    """
    items = []
    for entry in sorted(os.listdir(jvs_dir)):
        speaker_dir = os.path.join(jvs_dir, entry)
        if not os.path.isdir(speaker_dir) or not entry.startswith("jvs"):
            continue

        for subset in subsets:
            wav_dir = os.path.join(speaker_dir, subset, "wav24kHz16bit")
            if not os.path.isdir(wav_dir):
                continue

            for fname in sorted(os.listdir(wav_dir)):
                if not fname.lower().endswith('.wav'):
                    continue
                items.append((entry, subset, fname, os.path.join(wav_dir, fname)))

    return items


def make_unique_filename(speaker: str, subset: str, original: str) -> str:
    """生成全局唯一文件名: jvs001_parallel100_VOICEACTRESS100_001.wav"""
    return f"{speaker}_{subset}_{original}"


def convert_audio(src_path: str, dst_path: str, target_sr: int):
    """读取 24kHz wav → 重采样到 target_sr 单声道 → 写入 wav"""
    try:
        audio, sr = sf.read(src_path)

        # 多声道 → 单声道（取平均)
        if audio.ndim > 1:
            audio = audio.mean(axis=1)

        # 重采样到 target_sr
        if sr != target_sr:
            audio = librosa.resample(audio, orig_sr=sr, target_sr=target_sr)

        sf.write(dst_path, audio, target_sr)
        return True
    except Exception as e:
        print(f"  ❌ 转换失败 {src_path}: {e}")
        return False


# ── 主流程 ────────────────────────────────────────────────────────────

def main():
    print("=" * 60)
    print("  JVS 语料 → WavLM 性别检测训练数据 转换")
    print("=" * 60)

    # 1. 读取性别映射
    print(f"\n[1/4] 读取性别映射: {GENDER_FILE}")
    gender_map = parse_gender_map(GENDER_FILE)
    print(f"  共 {len(gender_map)} 个说话人")
    n_f = sum(1 for g in gender_map.values() if g == "female")
    n_m = sum(1 for g in gender_map.values() if g == "male")
    print(f"    女: {n_f}, 男: {n_m}")

    # 2. 扫描音频文件
    print("\n[2/4] 扫描音频文件...")
    all_files = collect_audio_files(JVS_DIR, SUBSETS)
    print(f"  共发现 {len(all_files)} 个 wav 文件 (子集: {', '.join(SUBSETS)})")

    # 按子集统计
    for subset in SUBSETS:
        count = sum(1 for _, s, _, _ in all_files if s == subset)
        print(f"    {subset}: {count} 个")

    # 3. 创建输出目录
    female_dir = os.path.join(OUTPUT_DIR, "female")
    male_dir = os.path.join(OUTPUT_DIR, "male")
    os.makedirs(female_dir, exist_ok=True)
    os.makedirs(male_dir, exist_ok=True)

    # 4. 转换并复制
    print("\n[3/4] 转换 → 16kHz 单声道,按性别分拣...")
    print(f"  输出目录: {OUTPUT_DIR}")
    start_time = time.time()

    converted = 0
    skipped = 0
    by_gender = {"female": 0, "male": 0}

    for speaker, subset, fname, abs_path in all_files:
        gender = gender_map.get(speaker)
        if gender is None:
            print(f"  ⚠️ 未知性别: {speaker}, 跳过 {fname}")
            skipped += 1
            continue

        out_name = make_unique_filename(speaker, subset, fname)
        out_path = os.path.join(OUTPUT_DIR, gender, out_name)

        if os.path.exists(out_path):
            # 文件已存在则跳过（支持断点续传)
            converted += 1
            by_gender[gender] += 1
            continue

        ok = convert_audio(abs_path, out_path, TARGET_SR)
        if ok:
            converted += 1
            by_gender[gender] += 1
        else:
            skipped += 1

        # 每 500 个汇报进度
        if converted % 500 == 0:
            elapsed = time.time() - start_time
            print(f"  进度: {converted}/{len(all_files)} 文件, 耗时 {elapsed:.0f}s")

    elapsed = time.time() - start_time
    print("\n[4/4] 转换完成!")
    print(f"  成功: {converted} 个")
    print(f"  跳过/失败: {skipped} 个")
    print(f"  女声: {by_gender['female']} 个 → {female_dir}")
    print(f"  男声: {by_gender['male']} 个 → {male_dir}")
    print(f"  总耗时: {elapsed:.0f}s ({elapsed/60:.1f}min)")

    # 估算总时长
    total_sec = 0
    for root, _, files in os.walk(OUTPUT_DIR):
        for fname in files:
            if fname.endswith('.wav'):
                try:
                    info = sf.info(os.path.join(root, fname))
                    total_sec += info.frames / info.samplerate
                except Exception:
                    pass
    print(f"\n  转换后总音频时长: {total_sec/3600:.1f} 小时")

    print("\n" + "=" * 60)
    print("  下一步: python training/prepare_dataset.py --data_dir training/data")
    print("  然后:   python training/train.py")
    print("=" * 60)


if __name__ == '__main__':
    main()
