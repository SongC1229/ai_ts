#!/usr/bin/env python3
"""VoiceGenderClassifier 日语性别检测微调

用法:
    python training_gender_cls/train.py
    python training_gender_cls/train.py --config training_gender_cls/configs/train_ja.yaml
    python training_gender_cls/train.py --eval-only
"""

import argparse
import os
import shutil
import sys
import time
import json
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, Dataset

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, PROJECT_ROOT)

import soundfile as sf
import numpy as np

from training.common import load_yaml, resolve_device  # noqa: E402


def get_linear_warmup_cosine_scheduler(optimizer, warmup_steps, total_steps):
    """warmup + cosine decay scheduler"""
    def lr_lambda(step):
        if step < warmup_steps:
            return float(step) / float(max(1, warmup_steps))
        progress = float(step - warmup_steps) / float(max(1, total_steps - warmup_steps))
        return 0.5 * (1.0 + np.cos(progress * np.pi))
    return torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda)


# ── 数据集 ────────────────────────────────────────────

class GenderDataset(Dataset):
    """VoiceGenderClassifier 训练数据集

    预处理与 core/gender_cls.py 的 predict() 严格一致:
    - 16kHz mono
    - 截断/补齐到 3 秒 (48000 采样)
    - mel 谱图 (80 bins, n_fft=512, hop=160)
    - power_to_db 归一化
    """

    def __init__(self, jsonl_path: str, max_sec: float = 3.0):
        self.max_samples = int(max_sec * 16000)
        self.items = []
        if not os.path.exists(jsonl_path):
            raise FileNotFoundError(f"JSONL 文件不存在: {jsonl_path}")
        with open(jsonl_path, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if line:
                    self.items.append(json.loads(line))
        if not self.items:
            raise ValueError(f"JSONL 文件为空: {jsonl_path}")

    def __len__(self):
        return len(self.items)

    def __getitem__(self, idx):
        item = self.items[idx]
        path = item["path"]
        label = item["label"]  # 0=female, 1=male
        start_sec = item.get("start_sec", 0)
        end_sec = item.get("end_sec", 0)

        if not os.path.isabs(path):
            path = os.path.join(PROJECT_ROOT, path)
        audio, sr = sf.read(path)
        if audio.ndim > 1:
            audio = audio.mean(axis=1)
        if sr != 16000:
            import librosa
            audio = librosa.resample(audio, orig_sr=sr, target_sr=16000)

        # 截取区间
        start = int(start_sec * 16000)
        end = int(end_sec * 16000) if end_sec > 0 else len(audio)
        if end > len(audio):
            end = len(audio)
        audio = audio[start:end]

        # 截断/补齐到 3 秒（与 predict() 一致）
        if len(audio) > self.max_samples:
            audio = audio[:self.max_samples]
        elif len(audio) < self.max_samples:
            audio = np.pad(audio, (0, self.max_samples - len(audio)))

        # 返回 raw waveform，mel 在 GPU 上计算
        return torch.from_numpy(audio).float(), label

def _mel_cpu(audio, sr=16000):
    """CPU 端计算 mel（备选，首次未编译时用）"""
    import librosa
    mel = librosa.feature.melspectrogram(y=audio, sr=sr, n_fft=512, hop_length=160, n_mels=80, fmin=20, fmax=8000)
    return librosa.power_to_db(mel, ref=1.0, top_db=80.0) / 80.0


def _collate_fn(batch):
    waveforms, labels = zip(*batch)
    return torch.stack(waveforms), torch.tensor(labels, dtype=torch.long)


def _mel_gpu(waveform: torch.Tensor, sr: int = 16000) -> torch.Tensor:
    """GPU 端计算 mel 谱图（替代 librosa，全在 CUDA 上运行）

    Args:
        waveform: (B, T) float32 tensor, 值域 [-1, 1], 已在 GPU 上
    Returns:
        (B, 80, T') float32 tensor
    """
    if waveform.dim() == 3:
        waveform = waveform.squeeze(1)
    elif waveform.dim() != 2:
        raise ValueError(f"波形形状异常: {waveform.shape}")
    B, T = waveform.shape
    n_fft = 512
    hop_length = 160
    n_mels = 80

    # STFT
    window = torch.hann_window(n_fft, device=waveform.device)
    n_fft // 2
    spec = torch.stft(waveform, n_fft=n_fft, hop_length=hop_length,
                      win_length=n_fft, window=window, pad_mode='reflect',
                      return_complex=True)  # (B, n_fft//2+1, T')
    mag = spec.abs() ** 2  # 功率谱（与 librosa 一致）

    # Mel 滤波器组（首次调用时创建并缓存）
    if not hasattr(_mel_gpu, '_mel_basis'):
        import librosa
        mel_basis_np = librosa.filters.mel(sr=sr, n_fft=n_fft, n_mels=n_mels, fmin=20, fmax=8000)
        _mel_gpu._mel_basis = torch.from_numpy(mel_basis_np).float()  # (80, 257)

    mel_basis = _mel_gpu._mel_basis.to(waveform.device)
    mel_spec = mel_basis @ mag  # (80, T')

    # power_to_db（与 librosa 一致：top_db 相对于谱图最大值）
    mel_spec = torch.clamp(mel_spec, min=1e-10)
    mel_db = 10 * torch.log10(mel_spec)
    max_val = mel_db.amax(dim=(1, 2), keepdim=True)
    mel_db = torch.clamp(mel_db, min=max_val - 80.0) / 80.0
    return mel_db  # (B, 80, T')


# ── 训练循环 ──────────────────────────────────────────

def evaluate(model, val_loader, device, fp16=False):
    model.eval()
    correct, total, correct_f, total_f, correct_m, total_m = 0, 0, 0, 0, 0, 0
    with torch.no_grad():
        for waveforms, labels in val_loader:
            waveforms, labels = waveforms.to(device), labels.to(device)
            mels = _mel_gpu(waveforms)
            with torch.amp.autocast('cuda', enabled=fp16 and device.type == 'cuda'):
                logits = model(mels)
            preds = logits.argmax(dim=1)
            correct += (preds == labels).sum().item()
            total += labels.size(0)
            is_f = labels == 0
            is_m = labels == 1
            correct_f += ((preds == labels) & is_f).sum().item()
            total_f += is_f.sum().item()
            correct_m += ((preds == labels) & is_m).sum().item()
            total_m += is_m.sum().item()
    acc = correct / total if total > 0 else 0.0
    f_acc = correct_f / total_f if total_f > 0 else 0.0
    m_acc = correct_m / total_m if total_m > 0 else 0.0
    model.train()
    return acc, correct, total, f_acc, m_acc


def main():
    parser = argparse.ArgumentParser(description="VoiceGenderClassifier 日语性别检测微调")
    parser.add_argument("--config", default="training_gender_cls/configs/train_ja.yaml",
                        help="配置文件路径")
    parser.add_argument("--eval-only", action="store_true", help="仅评估,不训练")
    args = parser.parse_args()

    # 加载配置
    cfg_path = os.path.join(PROJECT_ROOT, args.config) \
        if not os.path.isabs(args.config) else args.config
    cfg = load_yaml(cfg_path)
    print(f"  加载配置: {args.config}")
    for k, v in cfg.items():
        print(f"    {k}: {v}")

    # 设备
    device = resolve_device(cfg.get("device", "auto"))
    fp16 = cfg.get("fp16", True) and device.type == "cuda"
    use_amp = fp16
    print(f"  设备: {device}, FP16: {fp16}")

    # 数据
    print("  加载数据...")

    train_dataset = GenderDataset(os.path.join(PROJECT_ROOT, cfg['train_jsonl']), max_sec=3)
    val_dataset = GenderDataset(os.path.join(PROJECT_ROOT, cfg['val_jsonl']), max_sec=3)

    train_loader = DataLoader(
        train_dataset, batch_size=cfg.get('batch_size', 32), shuffle=True,
        num_workers=cfg.get('num_workers', 4), collate_fn=_collate_fn,
        pin_memory=device.type == 'cuda',
    )
    val_loader = DataLoader(
        val_dataset, batch_size=cfg.get('batch_size', 32) * 2, shuffle=False,
        num_workers=cfg.get('num_workers', 4), collate_fn=_collate_fn,
        pin_memory=device.type == 'cuda',
    )
    print(f"  训练: {len(train_dataset)} 条, 验证: {len(val_dataset)} 条")

    # 模型
    from core.gender_cls import VoiceGenderClassifier
    pretrained_path = os.path.join(PROJECT_ROOT, cfg['pretrained_dir'])
    print(f"  加载预训练模型: {pretrained_path}")
    model = VoiceGenderClassifier.from_pretrained(pretrained_path)
    model = model.to(device)
    model.train()

    n_params = sum(p.numel() for p in model.parameters())
    print(f"  总参数: {n_params:,}")

    # 自动恢复（先读取标量信息 + 加载模型权重；优化器/调度器状态待构建后再加载）
    start_epoch = 0
    best_val_acc = 0.0
    global_step = 0
    ckpt = None
    latest_ckpt = os.path.join(PROJECT_ROOT, "training_gender_cls", "checkpoints", "latest.pt")
    if os.path.exists(latest_ckpt):
        print(f"  检测到 checkpoint: {latest_ckpt}")
        ckpt = torch.load(latest_ckpt, map_location=device)
        model.load_state_dict(ckpt['model_state_dict'])
        start_epoch = ckpt['epoch'] + 1
        best_val_acc = ckpt.get('best_val_acc', 0.0)
        global_step = ckpt.get('global_step', 0)
        print(f"    从 epoch {start_epoch}, global_step {global_step} 恢复")

    # 优化器
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=cfg.get('lr', 5e-5),
        weight_decay=cfg.get('weight_decay', 0.01),
    )

    # 学习率调度（warmup 只在最开始做一次,恢复时不重新 warmup)
    epochs = cfg.get('epochs', 10)
    total_steps = len(train_loader) * epochs
    if start_epoch > 0:
        warmup_steps = 0
    else:
        warmup_steps = int(total_steps * cfg.get('warmup_ratio', 0.1))
    scheduler = get_linear_warmup_cosine_scheduler(optimizer, warmup_steps, total_steps)

    # 恢复优化器/调度器状态（在它们构建之后）
    if ckpt is not None:
        optimizer.load_state_dict(ckpt['optimizer_state_dict'])
        if 'scheduler_state_dict' in ckpt:
            scheduler.load_state_dict(ckpt['scheduler_state_dict'])

    criterion = nn.CrossEntropyLoss()

    # GradScaler（配合 fp16 autocast,防止梯度下溢出 NaN)
    scaler = torch.amp.GradScaler('cuda', enabled=use_amp)

    # 仅评估
    if args.eval_only:
        print("\n  ===== 评估模式 =====")
        acc, correct, total, f_acc, m_acc = evaluate(model, val_loader, device, use_amp)
        print(f"  验证集准确率: {acc:.4f} ({correct}/{total})")
        print(f"    女: {f_acc:.4f}, 男: {m_acc:.4f}")
        return

    # 输出目录
    output_dir = os.path.join(PROJECT_ROOT, cfg['output_dir'])
    os.makedirs(output_dir, exist_ok=True)

    # 训练循环
    print(f"\n  ===== 开始训练 ({epochs} epochs) =====")
    log_steps = cfg.get('log_steps', 20)
    no_improve_epochs = 0
    accum = max(cfg.get('gradient_accumulation_steps', 1), 1)

    for epoch in range(start_epoch, epochs):
        epoch_start = time.time()
        model.train()
        epoch_loss = 0.0

        for batch_idx, (waveforms, labels) in enumerate(train_loader):
            waveforms, labels = waveforms.to(device), labels.to(device)
            # GPU 上计算 mel 谱图
            mels = _mel_gpu(waveforms)
            if batch_idx == 0 and epoch == start_epoch:
                print(f"  模型设备: {next(model.parameters()).device}, 音频设备: {waveforms.device}, mel设备: {mels.device}")

            with torch.amp.autocast('cuda', enabled=use_amp):
                logits = model(mels)
                loss = criterion(logits, labels)
            loss = loss / accum
            scaler.scale(loss).backward()

            if (batch_idx + 1) % accum == 0:
                scaler.unscale_(optimizer)
                torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
                scaler.step(optimizer)
                scaler.update()
                scheduler.step()
                optimizer.zero_grad()

            epoch_loss += loss.item() * accum
            global_step += 1

            if (batch_idx + 1) % log_steps == 0:
                lr_now = optimizer.param_groups[0]['lr']
                print(f"    E{epoch+1}/{epochs} B{batch_idx+1}/{len(train_loader)} "
                      f"loss={loss.item()*accum:.4f} lr={lr_now:.2e}")

        avg_loss = epoch_loss / len(train_loader)
        epoch_time = time.time() - epoch_start
        print(f"\n  Epoch {epoch+1}/{epochs} avg_loss={avg_loss:.4f} time={epoch_time:.1f}s")

        # 验证
        acc, correct, total, f_acc, m_acc = evaluate(model, val_loader, device, use_amp)
        print(f"  验证: acc={acc:.4f} ({correct}/{total}) 女={f_acc:.4f} 男={m_acc:.4f}")

        if acc > best_val_acc:
            best_val_acc = acc
            no_improve_epochs = 0
            print(f"  🏆 最佳模型 (acc={acc:.4f})")
            _save_model(model, output_dir, cfg, epoch, acc)
        else:
            no_improve_epochs += 1
            print(f"  📉 连续 {no_improve_epochs} epoch 未提升")
        if no_improve_epochs >= cfg.get('early_stop_patience', 2) and epoch >= 2:
            print(f"  🛑 连续 {no_improve_epochs} epoch 验证准确率未提升,提前停止")
            break

        # 保存 checkpoint
        ckpt_dir = os.path.join(PROJECT_ROOT, "training_gender_cls", "checkpoints")
        os.makedirs(ckpt_dir, exist_ok=True)
        ckpt = {
            'epoch': epoch, 'global_step': global_step,
            'model_state_dict': model.state_dict(),
            'optimizer_state_dict': optimizer.state_dict(),
            'scheduler_state_dict': scheduler.state_dict(),
            'best_val_acc': best_val_acc,
        }
        torch.save(ckpt, os.path.join(ckpt_dir, f"checkpoint_epoch{epoch+1:02d}.pt"))
        torch.save(ckpt, os.path.join(ckpt_dir, "latest.pt"))

    print(f"\n  ===== 完成 ===== 最佳验证准确率: {best_val_acc:.4f}")


def _save_model(model, output_dir, cfg, epoch, val_acc):
    """保存模型产物：config.json + model.safetensors + README.md"""
    # 1. 复制 config.json
    src_config = os.path.join(PROJECT_ROOT, cfg['pretrained_dir'], "config.json")
    if os.path.exists(src_config):
        shutil.copy2(src_config, os.path.join(output_dir, "config.json"))

    # 2. 保存全量 state_dict（safetensors 格式)
    from safetensors.torch import save_file
    state_dict = {k: v.contiguous().cpu() for k, v in model.state_dict().items()}
    save_file(state_dict, os.path.join(output_dir, "model.safetensors"))

    # 3. 写入 README.md
    readme = f"""# VoiceGenderClassifier 日语性别检测模型

训练日期: {time.strftime('%Y-%m-%d')}
数据: {cfg.get('train_jsonl', 'unknown')}
验证准确率: {val_acc:.4f}
epoch: {epoch + 1}
"""
    with open(os.path.join(output_dir, "README.md"), 'w', encoding='utf-8') as f:
        f.write(readme)


if __name__ == '__main__':
    main()
