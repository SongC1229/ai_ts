# VoiceGenderClassifier 日语性别检测微调

## 环境要求

使用项目已有的依赖：
- torch >= 2.x
- soundfile, librosa, numpy
- tqdm

## 数据准备

使用 `training/` 目录下的数据准备脚本：

```bash
# 把 JVS 音频放到 training/data/{female,male}/
python training/prepare_dataset.py --data_dir training/data
```

## 训练

```bash
python training_gender_cls/train.py
```

默认从 `training/configs/train_ja.yaml` 读取配置。
首次从 `models/voice-gender-classifier/` 加载预训练权重，
有 `training_gender_cls/checkpoints/latest.pt` 时自动恢复续训。

## 产物

```
models/voice-gender-classifier-ja/
├── model.safetensors           # 微调后权重
└── README.md                   # 训练记录
```

替换 `models/voice-gender-classifier/model.safetensors` 即可使用。
